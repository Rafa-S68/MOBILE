package com.example.pokemonapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.pokemonapp.databinding.ItemPokemonBinding
import com.example.pokemonapp.Model.PokemonEntity
import com.squareup.picasso.Picasso

class PokemonAdapter : ListAdapter<PokemonEntity, PokemonAdapter.PokemonViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PokemonViewHolder {
        val binding = ItemPokemonBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PokemonViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PokemonViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class PokemonViewHolder(private val binding: ItemPokemonBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(pokemon: PokemonEntity) {
            binding.pokemonName.text = pokemon.name
            binding.pokemonHeight.text = "Altura: ${pokemon.height}"
            binding.pokemonWeight.text = "Peso: ${pokemon.weight}"
            binding.pokemonTypes.text = "Tipos: ${pokemon.types}"
            Picasso.get().load(pokemon.imageUrl).into(binding.pokemonImage)
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<PokemonEntity>() {
        override fun areItemsTheSame(oldItem: PokemonEntity, newItem: PokemonEntity) = oldItem.name == newItem.name
        override fun areContentsTheSame(oldItem: PokemonEntity, newItem: PokemonEntity) = oldItem == newItem
    }
}
