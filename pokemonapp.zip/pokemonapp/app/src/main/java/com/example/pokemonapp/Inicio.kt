package com.example.pokemonapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class Inicio : AppCompatActivity() {
    private lateinit var videoView: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio)

        videoView = findViewById(R.id.videoFundo)

        // Path do vídeo na pasta raw
        val videoUri = Uri.parse("android.resource://${packageName}/${R.raw.fundo}")

        videoView.setVideoURI(videoUri)

        videoView.setOnPreparedListener { mediaPlayer ->
            mediaPlayer.isLooping = true

            // Ajusta o tamanho do VideoView para fazer centerCrop
            val videoWidth = mediaPlayer.videoWidth
            val videoHeight = mediaPlayer.videoHeight
            val videoProportion = videoWidth.toFloat() / videoHeight

            val screenWidth = videoView.width.toFloat()
            val screenHeight = videoView.height.toFloat()
            val screenProportion = screenWidth / screenHeight

            val lp = videoView.layoutParams

            if (videoProportion > screenProportion) {
                lp.height = screenHeight.toInt()
                lp.width = (screenHeight * videoProportion).toInt()
            } else {
                lp.width = screenWidth.toInt()
                lp.height = (screenWidth / videoProportion).toInt()
            }

            videoView.layoutParams = lp

            videoView.start()
        }

        // Após 5 segundos, abre a MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 7000)
    }
}
