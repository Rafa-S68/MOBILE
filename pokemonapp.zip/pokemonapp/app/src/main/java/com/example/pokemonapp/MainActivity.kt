package com.example.pokemonapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.example.pokemonapp.databinding.ActivityMainBinding
import com.example.pokemonapp.ui.PokemonAdapter
import com.example.pokemonapp.ui.PokemonViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: PokemonViewModel
    private lateinit var adapter: PokemonAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        )[PokemonViewModel::class.java]

        adapter = PokemonAdapter()
        binding.recyclerView.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerView.adapter = adapter


        viewModel.sessionHistory.observe(this) { list ->
            adapter.submitList(list)
        }

        binding.searchButton.setOnClickListener {
            val nome = binding.pokemonNameEditText.text.toString().lowercase().trim()
            if (nome.isNotEmpty()) {
                viewModel.fetchPokemon(nome)
                binding.pokemonNameEditText.text.clear()
            } else {
                Toast.makeText(this, "Digite um nome de Pokémon", Toast.LENGTH_SHORT).show()
            }
        }


        binding.clearButton.setOnClickListener {
            viewModel.clearSessionHistory()
            Toast.makeText(this, "Lista da sessão limpa", Toast.LENGTH_SHORT).show()
        }

        binding.historyButton.setOnClickListener {
            startActivity(Intent(this, HistoricoActivity::class.java))
        }
    }
}
