package com.example.pokemonapp.Dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.pokemonapp.Model.PokemonEntity

@Dao
interface PokemonDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pokemon: PokemonEntity)

    @Query("SELECT * FROM pokemon ORDER BY name ASC")
    fun getAll(): LiveData<List<PokemonEntity>>

    @Query("DELETE FROM pokemon")
    suspend fun deleteAll()
}
