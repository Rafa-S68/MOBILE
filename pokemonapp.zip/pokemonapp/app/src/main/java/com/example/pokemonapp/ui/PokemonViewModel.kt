package com.example.pokemonapp.ui

import android.app.Application
import androidx.lifecycle.*
import com.example.pokemonapp.Model.PokemonDatabase
import com.example.pokemonapp.Model.PokemonEntity
import com.example.pokemonapp.remote.RetrofitInstance
import kotlinx.coroutines.launch

class PokemonViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = PokemonDatabase.getDatabase(application).pokemonDao()
    private val _pokemonLiveData = MutableLiveData<PokemonEntity>()
    val pokemonLiveData: LiveData<PokemonEntity> = _pokemonLiveData


    private val _sessionHistory = MutableLiveData<List<PokemonEntity>>(emptyList())
    val sessionHistory: LiveData<List<PokemonEntity>> = _sessionHistory

    fun fetchPokemon(name: String) {
        viewModelScope.launch {
            try {
                val response = RetrofitInstance.api.getPokemon(name)
                val types = response.types.joinToString(", ") { it.type.name }

                val entity = PokemonEntity(
                    name = response.name,
                    imageUrl = response.sprites.front_default,
                    height = response.height,
                    weight = response.weight,
                    types = types
                )


                dao.insert(entity)


                val currentList = _sessionHistory.value ?: emptyList()
                _sessionHistory.postValue(currentList + entity)

                _pokemonLiveData.postValue(entity)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun getSearchHistory() = dao.getAll()


    fun clearSessionHistory() {
        _sessionHistory.postValue(emptyList())
    }
}
